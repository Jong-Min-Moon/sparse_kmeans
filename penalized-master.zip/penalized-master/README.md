# Penalized
Penalized is a Matlab toolbox for penalized regression, penalized logisitc regression, etc. It has been accepted by 
Journal of Statistical Software, but made available here pre-publication. 

To learn more, read the file `penalized.pdf` (particularly the tutorial section). This is the same as the accepted article.
